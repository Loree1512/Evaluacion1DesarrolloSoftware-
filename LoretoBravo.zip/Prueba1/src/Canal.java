/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Canal {
    private String nombre;
    private String descripcion;
    private int videos;
    private int suscriptores;
    private Cuenta cuenta;
}

public getNombre(String nombre){
    return nombre;
}

public getDescripcion(String descripcion){
    return descripcion;
}

public getVideos(int videos){
    return videos;
}

public getSuscriptores (int suscriptores){
    return suscriptores;
}
